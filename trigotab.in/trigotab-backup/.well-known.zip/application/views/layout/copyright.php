<div class="footer_bottom text-center">
        <p>Copyright &copy; <script>document.write(new Date().getFullYear())</script> All Rights Reserved by <a href="https://www.heterohealthcare.com/" target="_blank">Hetero Healthcare Limited.</a></p>
    </div>  