<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Admin extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->database();
		$this->load->model('Home_model');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->helper('cookie');
		$this->load->helper('url', 'form', 'string');
		// For Error Reporting
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);
	}
	public function login() {
		$data=array();
		date_default_timezone_set('Asia/Kolkata');
		$objDate = new DateTime();

        if ($this->input->post('submit')){
			//echo "<pre>"; print_r($_POST); exit;
			$this->form_validation->set_rules('username','Enter Username','required');
			$this->form_validation->set_rules('password','Enter Password','required');
			$this->form_validation->set_error_delimiters('<div class="error">','</div>');
			$this->form_validation->set_message('required', 'Enter %s');
			if($this->form_validation->run()==False){
				//echo validation_errors();
				$data['error'] = validation_errors();
				//echo "<pre>"; print_r($data); exit;
				$this->load->view('admin/index', $data);
			}
			else{
				//echo "In"; exit;
				$where = array('username'=> $this->input->post('username'),'password'=> $this->input->post('password'), 'status'=> '1001');
				$data['userdata']=$this->Home_model->getData('db', 'users', '*', $where, '', '', '', '');
				//echo "<pre>"; Print_r($data); exit;
				$sessiondata = array('id'=>$data['userdata'][0]['id'],'username'=>$data['userdata'][0]['username'],'status'=>$data['userdata'][0]['status'],'dpname'=>$data['userdata'][0]['dpname'],'dpimage'=>$data['userdata'][0]['dpimage']);				
				if(!empty($data['userdata'])){
					//echo $data['userdata'][0]['username']; exit;
					$this->session->set_userdata($sessiondata);
					redirect('dashboard');
				}
				else {
					$data['error'] = '<div class="error">Invalid Username and Password</div>';
					$this->load->view('admin/index', $data);
				}	
			}
		}
		else{
			$this->load->view('admin/index', $data);
		}
    }
    public function User_Auth() {
		// echo"<pre>"; print_r($this->session->all_userdata());
		// exit;
        if ($this->session->userdata('id')) {
            return true;
        } else {
            return false;
        }
    }
    public function logout() {
		//echo "In"; exit;
        $this->session->unset_userdata('id');
        $this->session->sess_destroy();
        redirect('');
    }
	public function dashboard() {
		$data = array();
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}
		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/dashboard', $data);
	}
	public function contents() {
		$data = array();
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}

		$data = array();
        $tableA = 'contents';
        $tableB = 'content_group';
        $key1 = 'group_code';
        $key2 = 'group_code';
        $tableC = '';
        $key3 = '';
        $key4 = '';
        $tableD = '';
        $key5 = '';
        $key6 = '';
        $tableE = '';
        $key7 = '';
        $key8 = '';
        $tableF = '';
        $key9 = '';
        $key10 = '';
        $tableG = '';
        $key11 = '';
        $key12 = '';
        $getdata = '';
        $where = '';
        $data['contents'] = $this->Home_model->getDatajoin('db', $tableA, $tableB, $key1, $key2, $getdata, $where, 'A.content_id', 'DESC', '', $tableC, $key3, $key4, $tableD, $key5, $key6, $tableE, $key7, $key8, $tableF, $key9, $key10, $tableG, $key11, $key12);
		
		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/contents', $data);
	}
	public function content_create() {
		$data = array();
		date_default_timezone_set('Asia/Kolkata');
		$objDate = new DateTime();
		$this->load->helper('string');			
		$content_code = random_string('nozero',10);
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}
		
		if($this->input->post('create')){
    		//echo "<pre>"; print_r($_POST); exit;
    		$add_content = array('content_code' => $content_code, 
    		    'content' => $this->input->post('content'),
    		    'group_code' => $this->input->post('group_code'),
    		    'content_updatedby' => $this->input->post('logid'),
    		    'content_updatedon' => $objDate->format('Y-m-d H:i:s'),
    		    'content_createdby' => $this->input->post('logid'),
    		    'content_createdon' => $objDate->format('Y-m-d H:i:s'));
    		//echo "<pre>"; print_r($add_content); exit;
    		$insert_content = $this->Home_model->insertData('db', 'contents', $add_content);
    		$add_content_history = array(
    		    'content_id' => $insert_content,
    		    'content_code' => $content_code, 
    		    'content' => $this->input->post('content'),
    		    'group_code' => $this->input->post('group_code'),
    		    'content_updatedby' => $this->input->post('logid'),
    		    'content_updatedon' => $objDate->format('Y-m-d H:i:s'),
    		    'content_createdby' => $this->input->post('logid'),
    		    'content_createdon' => $objDate->format('Y-m-d H:i:s'),
    		    'content_reason_for_update' => 'New Entry');
    		//echo "<pre>"; print_r($add_content_history); exit;
    		$insert_content = $this->Home_model->insertData('db', 'contents_history', $add_content_history);
    		redirect('contents');
		}
		else{
		    $where = "group_status = '1001'";
	        $data['contentgroups'] = $this->Home_model->getData('db', 'content_group', '', $where, '', '', '', '');
		}
		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/content_create', $data);
	}
	public function contents_edit() {
		$data = array();
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}
		if($this->input->post('update')){
		    $update_content = array(
              'content_code' => $this->input->Post('content_code'),  
              'content' => $this->input->Post('content'),  
              'content_status' => $this->input->Post('content_status'),
              'content_createdby' => $this->input->Post('content_createdby'),
              'content_createdon' => $this->input->Post('content_createdon'),
              'content_updatedby' => $this->input->post('emp_id'),
              'content_updatedon' => $objDate->format('Y-m-d H:i:s')
            ); 
            $where= array('content_id'=>$this->input->post('content_id'));
            $this->Home_model->updateData('db', 'contents', $update_content, $where); 
            $add_content_history = array(
    		    'content_id' => $this->input->post('content_id'),
    		    'content_code' => $this->input->post('content_code'), 
    		    'content' => $this->input->post('content'),
    		    'content_status' => $this->input->Post('content_status'),
    		    'content_updatedby' => $this->input->post('emp_id'),
    		    'content_updatedon' => $objDate->format('Y-m-d H:i:s'),
    		    'content_createdby' => $this->input->post('content_createdby'),
    		    'content_createdon' => $this->input->post('content_createdon'),
    		    'content_reason_for_update' => $this->input->post('content_reason_for_update'));
    		echo "<pre>"; print_r($add_content_history); exit;
    		$insert_content = $this->Home_model->insertData('db', 'contents_history', $add_content_history);
            
            redirect('contents');   
		}
		else{
		    $getdata = '';
            $where= array('content_id'=>$this->input->get('id'));
            $data['content_info']=$this->Home_model->getData('db', 'contents', $getdata,  $where,'','','','');
		}
		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/contents_edit', $data);
	}
	public function contentgroups() {
		$data = array();
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}
		$where = '';
		$data['contentgroups'] = $this->Home_model->getData('db', 'content_group', '', $where, '', 'content_group_id', 'DESC', '');
		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/content_group_list', $data);
	}
	public function contentgroups_create() {
		$data = array();
		date_default_timezone_set('Asia/Kolkata');
		$objDate = new DateTime();
		$this->load->helper('string');			
		$content_code = random_string('nozero',10);
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}
		
		if($this->input->post('create')){
    	    //echo "<pre>"; print_r($_POST); exit;
    		$add_content_group = array('group_code' => $content_code, 
    		    'group_name' => $this->input->post('group_name'),
    		    'group_updatedby' => $this->input->post('logid'),
    		    'group_updatedon' => $objDate->format('Y-m-d H:i:s'),
    		    'group_createdby' => $this->input->post('logid'),
    		    'group_createdon' => $objDate->format('Y-m-d H:i:s'));
    		//echo "<pre>"; print_r($add_content_group); exit;
    		$insert_content_group = $this->Home_model->insertData('db', 'content_group', $add_content_group);
    		
    		$add_content_group_history = array(
    		    'content_group_id' => $insert_content_group,
    		    'group_code' => $content_code, 
    		    'group_name' => $this->input->post('content'),
    		    'group_updatedby' => $this->input->post('logid'),
    		    'group_updatedon' => $objDate->format('Y-m-d H:i:s'),
    		    'group_createdby' => $this->input->post('logid'),
    		    'group_createdon' => $objDate->format('Y-m-d H:i:s'),
    		    'group_reason_for_update' => 'New Entry');
    		//echo "<pre>"; print_r($add_content_group_history); exit;
    		$insert_content_group_history = $this->Home_model->insertData('db', 'content_group_history', $add_content_group_history);
    		redirect('content-groups');
		}
		else{
		    
		}
		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/contentgroups_create', $data);
	}
	public function contentgroups_edit() {
		$data = array();
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}
		if($this->input->post('update')){
		    $update_content = array(
              'group_code' => $this->input->Post('group_code'),  
              'group_name' => $this->input->Post('group_name'),  
              'group_status' => $this->input->Post('group_status'),
              'group_createdby' => $this->input->Post('group_createdby'),
              'group_createdon' => $this->input->Post('group_createdon'),
              'group_updatedby' => $this->input->post('emp_id'),
              'group_updatedon' => $objDate->format('Y-m-d H:i:s')
            ); 
            $where= array('content_group_id'=>$this->input->post('content_group_id'));
            $this->Home_model->updateData('db', 'content_group', $update_content, $where); 
            
            $add_content_group_history = array(
    		    'content_group_id' => $this->input->post('content_group_id'),
    		    'group_code' => $this->input->post('group_code'), 
    		    'group_name' => $this->input->post('content'),
    		    'group_status' => $this->input->Post('group_status'),
    		    'group_updatedby' => $this->input->post('logid'),
    		    'group_updatedon' => $objDate->format('Y-m-d H:i:s'),
    		    'group_createdby' => $this->input->post('group_createdby'),
    		    'group_createdon' => $this->input->post('group_createdon'),
    		    'group_reason_for_update' => $this->input->post('group_reason_for_update'));
    		echo "<pre>"; print_r($add_content_group_history); exit;
    		$insert_content_group_history = $this->Home_model->insertData('db', 'content_group_history', $add_content_group_history);
            
            redirect('content-groups');   
		}
		else{
		    $getdata = '';
            $where= array('content_group_id'=>$this->input->get('id'));
            $data['content_info']=$this->Home_model->getData('db', 'content_group', $getdata,  $where,'','','','');
		}

		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/contentgroups_edit', $data);
	}
	public function pages() {
		$data = array();
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}
		//$where = '';
		//$data['pages'] = $this->Home_model->getData('db', 'pages', '', $where, '', 'content_group_id', 'DESC', '');
		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/contents', $data);
	}
	public function pages_create() {
		$data = array();
		date_default_timezone_set('Asia/Kolkata');
		$objDate = new DateTime();
		$this->load->helper('string');			
		$content_code = random_string('nozero',10);
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}
		
		if($this->input->post('create')){
		    echo "<pre>"; print_r($_POST); exit;
    		//Get Last Page ID
    		$getdata = '';
    		$data['pageinfo'] = $this->Home_model->getData('db', 'pages', '', $where, '', 'id', 'DESC', '');
            $pageid = $data['pageinfo'][0]['page_id']+1;
    		$add_create_page = array(
                'page_id' => $pageid,
                'pagegroup_id' => $this->input->post('pagegroup_id'),
                'createdby' => $this->input->post('logid'),
                'createdon' => $objDate->format('Y-m-d H:i:s'));
                 //echo "<pre>"; print_r($add_create_page); exit;
            $add_create_page = $this->Home_model->insertData('db', 'pages', $add_create_page); 
    		
    		$add_create_app_routes = array( 
    		    'slug' => $url,
    		    'controller' => 'Home/'.$pagename,
    		    'page_id' => $pageid,
    		    'pagegroup_id' => $this->input->post('pagegroup_id'),
    		    'updatedby' => $this->input->post('logid'),
    		    'updatedon' => $objDate->format('Y-m-d H:i:s'),
    		    'createdby' => $this->input->post('logid'),
    		    'createdon' => $objDate->format('Y-m-d H:i:s'));
    		echo "<pre>"; print_r($add_create_app_routes); exit;
    		$insert_create_app_routes = $this->Home_model->insertData('db', 'app_routes', $add_create_app_routes);
    		redirect('pages');
		}
		else{
		    $where = "pagegroup_status = '1001'";
	        $data['pagegroups'] = $this->Home_model->getData('db', 'pagegroup', '', $where, '', '', '', '');
		}
		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/contentgroups_create', $data);
	}
	public function leads() {
		$data = array();
		if ($this->User_Auth()) {} else {
			//$this->load->view('admin/login');
			redirect('login');
		}
	    
	    if($this->input->post('search')){
	        
	        if(empty($this->input->post('date_from')) AND empty($this->input->post('date_to'))){
                // echo "In"; exit;
                redirect('leads'); exit;
            }
            
            $data['date_from'] = $this->input->post('date_from');
            $data['date_to'] = $this->input->post('date_to');
            $from = $this->input->post('date_from').' 00:00:00';
            $to = $this->input->post('date_to').' 23:59:59';
            
            $where = "leads_status = '1001' AND leads_date BETWEEN '$from' AND '$to'";
	        $data['leads'] = $this->Home_model->getData('db', 'leads', '', $where, '', 'leads_id', 'DESC', '');
	    }
	    else{
	        $data['leads'] = $this->Home_model->getData('db', 'leads', '', $where, '', 'leads_id', 'DESC', '');
	    }
		//echo "<pre>"; print_r($data); exit;
		$this->load->view('admin/leads', $data);
	}
	public function  statuschangenew(){
        //echo "<pre>"; print_r($_POST);  exit;
        $db = $this->input->post('db');
        $table = $this->input->post('table');     
        $colum = $this->input->post('colum');
        $Rcolum = $this->input->post('Rcolum'); 
        
        if($this->input->post('status') == '1002'){ $value = '1001'; } else { $value = '1002';}
        
        $update_status = array(
          $colum => $value,
        ); 
        
        //print_r($update_status); exit;
        $where = array($Rcolum => $this->input->post('id'));
        $this->Home_model->updateData($db, $table, $update_status, $where);
    }
}
?>
