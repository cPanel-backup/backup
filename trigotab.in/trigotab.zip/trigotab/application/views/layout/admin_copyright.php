<section class="copyright">
	<footer>
		<div class="container-fluid text-center">
			<div class="row">
				<!-- <div class="col-lg-12 col-md-12 col-sm-12">
					<ul class="list-inline">
						<li class="list-inline-item"><a href="#home" id="home">Home</a></li>
						<li class="list-inline-item"><a href="#aboutus">About Us</a></li>
						<li class="list-inline-item"><a href="#blog">Blog</a></li>
						<li class="list-inline-item"><a href="#testimonials">Testimonials</a></li>
						<li class="list-inline-item"><a href="#faq">FAQs</a></li>
						<li class="list-inline-item"><a href="#contactus">Contact Us</a></li>
					</ul>
				</div> -->
				<?php if(Disclaimer == 'True'){ ?>
				<div class="col-lg-12 col-md-12 col-sm-12">
					<p><strong>Disclaimer:</strong> The content mentioned in this website is based on the published literature and is for informational purposes only. Hetero Healthcare makes every effort to present accurate and reliable information, but does not warrant, or assume any legal liability or responsibility for, the accuracy or completeness of any information provided. The product prescribing information complies with drug approval for use in Indian and may not reflect regulatory approvals of other countries. The patient information is not intended to substitute professional advice and services of a qualified healthcare professional. Any advice regarding the management of the medical condition is totally in the discreet of the physician’s knowledge and expertise.</p>
				</div><?php } ?>
				<div class="col-lg-12 col-md-12 col-sm-12 mt-2">
					<p>Copyright &copy; <script>document.write(new Date().getFullYear())</script> All Rights Reserved by <?php echo Copyright; ?></a></p>
				</div>
			</div>
		</div>
	</footer>
</section>

<!--<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>-->