<section class="copyright">
	
</section>

<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>