<section class="" id="contactus">
    <footer>
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <img src="<?php echo base_url();?>assets/img/trigotab-logo.svg" class="footer_logo"/>
                    <h6>Fenugreek Seed Powder Tablet<br> 1000mg</h6>
                </div>
                <div class="col-lg-5">
                    <h4>Quick Links</h4>
                    <div class="row">
                        <div class="col-6">
                            <ul style="list-style-type:none;">
                                <li><a href="#" target="_blank">Home</a></li>
                                <li><a href="#" target="_blank">About Trigotab</a></li>
                                <li><a href="#" target="_blank">Expert Advice</a></li>
                                <li><a href="#" target="_blank">Blog</a></li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <ul style="list-style-type:none;">
                                <li><a href="#" target="_blank">FAQ</a></li>
                                <li><a href="#" target="_blank">Contact Us</a></li>
                                <li><a href="#" target="_blank">Scientific Information</a></li>
                                <li><a href="#" target="_blank">Case Studies</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <h4>Follow us on</h4>
                    <div class="social_icons">
                        <a href="https://www.facebook.com/HeteroHealthcareOfficial/" target="_blank" class="mr-3 socialLink"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                        <a href="https://www.youtube.com/HeteroHealthCareLimited" target="_blank" class="mr-3 socialLink"><i class="fa fa-youtube-play" aria-hidden="true"></i></a>
                        <a href="https://twitter.com/HeteroHCL" target="_blank" class="mr-3 socialLink"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                        <a href="https://in.linkedin.com/company/hetero-healthcare-limited" target="_blank" class="mr-3 socialLink"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <div class="copyright_txt">
        <p>Copyright © <script>
                document.write(new Date().getFullYear())
            </script> All Rights Reserved by <u><a href="https://www.heterohealthcare.com"
                    target="_blank">Hetero Healthcare Limited</a></u>.</p>
    </div>
</section>