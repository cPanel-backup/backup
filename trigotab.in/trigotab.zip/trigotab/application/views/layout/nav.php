    <!-- Nav Menu  -->
    <div class="">
        <!-- navbar-me -->
            <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
            <div class="container">
                <a class="navbar-brand" href="<?php echo base_url();?>"><img src="<?php echo base_url();?>assets/img/trigotab-logo.svg" class="trigotab_logo" /></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto scrollpy">
                        <li class="nav-item">
                            <a class="nav-link" name='link' href="<?php echo base_url();?>">Home</a>
                        </li>
                        <li class="nav-item ml-md-1">
                            <a class="nav-link" name='link' href="<?php echo base_url();?>about-trigotab">About Trigotab</a>
                        </li>
                        <li class="nav-item ml-md-1">
                            <a class="nav-link" name='link' href="<?php echo base_url();?>expert-advice">Expert Advice</a>
                        </li>
                        <li class="nav-item ml-md-1">
                            <a class="nav-link" name='link' href="<?php echo base_url();?>blog">Blog</a>
                        </li>
                        <li class="nav-item ml-md-1">
                            <a class="nav-link" name='link' href="<?php echo base_url();?>contactUs">Contact Us</a>
                        </li>
                    </ul>
                </div>
            </nav>
		</div>
</div>
	</div>