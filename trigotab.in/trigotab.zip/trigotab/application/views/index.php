<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view('layout/meta');  ?>
	<?php $this->load->view('layout/styles');  ?>
</head>

<body id="body" data-spy="scroll" data-target=".navbar" data-offset="50">
	<!-- Page Loading -->
	<div id="loading"></div>

	<?php $this->load->view('layout/nav');  ?>

	<section class="index_top_sec pt-100">
		<img src="<?php echo base_url();?>assets/img/leaves.png" class="leaves_img" />
		<div class="d-flex">
			<div class="index_top_left_sec">
				<h6 class="heading1">1 gm Innovation</h6>
				<h1 class="heading2">Naturally Control Diabetes: Harness the Healing Power of Fenugreek</h1>
				<div class="btn_cont">
					<a href="#" class="btn">Buy Now</a>
					<a href="#" class="btn">Know More</a>
				</div>
			</div>
			<div class="index_top_right_sec">
				<img src="<?php echo base_url();?>assets/img/trigotab_packshot.png" />
			</div>
		</div>
	</section>

	<section class="instructions_cont">
		<div class="instructions_cont_left_sec">
			<img src="<?php echo base_url();?>assets/img/family_img.png" class="family_img" />
		</div>
		<div class="instructions_cont_right_sec">
			<h4 class="side_heading">Traditional Belief + Modern Science</h4>
			<div class="inst">
				<div class="left_inst">
					<div class="instruction">
						<img src="<?php echo base_url();?>assets/img/Ellipse1.png" class="right_icon" />
						<p>3 Times a day</p>
					</div>
					<div class="instruction">
						<img src="<?php echo base_url();?>assets/img/Ellipse2.png" class="icon" />
						<p>High content of Trigonelline <br>(>4000mcg/ Tab)</p>
					</div>
					<div class="instruction">
						<img src="<?php echo base_url();?>assets/img/Ellipse3.png" class="icon" />
						<p>Better Glycemic control.</p>
					</div>
					<div class="instruction">
						<img src="<?php echo base_url();?>assets/img/Ellipse4.png" class="icon" />
						<p>Helps in boosting immune system.</p>
					</div>
				</div>
				<div class="right_inst">
					<div class="instruction">
						<img src="<?php echo base_url();?>assets/img/Ellipse1.png" class="right_icon" />
						<p>14 Nutrients</p>
					</div>
					<div class="instruction">
						<img src="<?php echo base_url();?>assets/img/Ellipse5.png" class="icon" />
						<p>It helps in pancreatic <strong>β</strong> cells<br> regeneration.</p>
					</div>
					<div class="instruction">
						<img src="<?php echo base_url();?>assets/img/Ellipse6.png" class="icon" />
						<p>Rich in Antioxidants.</p>
					</div>
					<div class="instruction">
						<img src="<?php echo base_url();?>assets/img/Ellipse7.png" class="icon" />
						<p>Reduction in Glycemic<br> Variability. Significant benefits<br> in dyslipidemia</p>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="ingredients_sec">
		<div class="container">
			<div class="row ingredients_sec_inner_cont">
				<div class="col-md-6 ingredients_left_sec">
					<h4 class="side_heading">What’s Inside</h4>
					<h4>Nature’s Gift <strong>Fenugreek</strong> (Methi) known for its
						<strong>“Anti - Hyperglycaemic Action.”</strong></h4>
					<a href="#" class="btn">Know more</a>
				</div>
				<div class="col-md-6 ingredients_right_sec">
					<img src="<?php echo base_url();?>assets/img/fenugreek-seeds-with-green-leaves.png" class="" />
				</div>
			</div>
		</div>
	</section>

	<section class="info_sec">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 info_sec_top">
					<h4 class="side_heading">What makes TRIGOTAB so unique?</h4>
					<p>For example, each 1 gm sprout of Fenugreek usually contains 300-500 mcg of<br> Trigonelline.
						Whereas
						each tablet of TRIGOTAB (1gm) contains >4000 mcg of<br> Trigonelline. (>10 times from natural
						source).</p>
					<h6>The Power to Control</h6>
				</div>
				<div class="col-sm-4 info_sec_inner">
					<div class="info_sec_content">
						<h5>Trigonelline</h5>
						<p class="bold_text">Insulin Secretion</p>
						<p class="normal_text">Lorem Ipsum is simply dummy text of the printing and typesetting
							industry.</p>
					</div>
					<div class="info_sec_content">
						<h5>4 Hydroxy Isoluceine</h5>
						<p class="bold_text">Insulin Secretion</p>
						<p class="normal_text">Lorem Ipsum is simply dummy text of the printing and typesetting
							industry.</p>
					</div>
				</div>
				<div class="col-sm-4 info_mid_sec">
					<img src="<?php echo base_url();?>assets/img/trigotab_packshot2.png" class="trigotab_packshot2" />
					<img src="<?php echo base_url();?>assets/img/hand_img.png" class="hand_img" />
				</div>
				<div class="col-sm-4 info_sec_inner">
					<div class="info_sec_content">
						<h5>Galactomannan</h5>
						<p class="bold_text">Delays Carbohydratre digestion & absorption</p>
						<p class="normal_text">Lorem Ipsum is simply dummy text of the printing and typesetting
							industry.</p>
					</div>
					<div class="info_sec_content">
						<h5>Saponin</h5>
						<p class="bold_text">Glucose Uptake</p>
						<p class="normal_text">Lorem Ipsum is simply dummy text of the printing and typesetting
							industry.</p>
					</div>
				</div>
			</div>
		</div>
	</section>


	<section class="who_should_use">
		<div class="who_should_use_left_Sec">
			<img src="<?php echo base_url();?>assets/img/family_img1.png" class="family_img" />
		</div>
		<div class="who_should_use_right_Sec">
			<h4 class="side_heading">Who should use</h4>
			<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections
				1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact
				original form</p>
			<ul>
				<li>
					<h6 style="display:inline-flex;">&#8226<strong> To all Diabetics including patients with stubborn
							glucose control.</strong></h6>
				</li>
			</ul>
		</div>
	</section>

	<section class="how_to_use">
		<div class="container">
			<div class="row">
				<div class="col-sm-12 text-center">
					<h4 class="side_heading">How to use</h4>
				</div>
				<div class="col-sm-4 text-center">
					<img src="<?php echo base_url();?>assets/img/step1.png" class="usage" />
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				</div>
				<div class="col-sm-4 text-center">
					<img src="<?php echo base_url();?>assets/img/step2.png" class="usage" />
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				</div>
				<div class="col-sm-4 text-center">
					<img src="<?php echo base_url();?>assets/img/step3.png" class="usage" />
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
				</div>
			</div>
		</div>
	</section>

	<section class="expert_info">
		<h6>For Experts Information</h6>
		<h3>An add-on Towards <br>stepping down.</h3>
		<div class="btn_cont">
			<a href="#" class="btn mr-md-4">Scientific Informaation</a>
			<a href="#" class="btn">Case studies</a>
		</div>
	</section>

	<section class="index_pg_bot_sec">
		<h4 class="side_heading">Order Now from</h4>
		<a href="#" target="_blank"><img src="<?php echo base_url();?>assets/img/azista_icon.svg"
				class="social_icon" /></a>
		<h4 class="side_heading">Also available at</h4>
		<div class="container">
			<div class="row">
				<div class="col-sm-3 text-center">
					<a href="#" target="_blank"><img src="<?php echo base_url();?>assets/img/netmeds.svg"
							class="external_social_icon" /></a>
				</div>
				<div class="col-sm-3 text-center">
					<a href="#" target="_blank"><img src="<?php echo base_url();?>assets/img/amazon.svg"
							class="external_social_icon" /></a>
				</div>
				<div class="col-sm-3 text-center">
					<a href="#" target="_blank"><img src="<?php echo base_url();?>assets/img/flipkart.svg"
							class="external_social_icon" /></a>
				</div>
				<div class="col-sm-3 text-center">
					<a href="#" target="_blank"><img src="<?php echo base_url();?>assets/img/tata.svg"
							class="external_social_icon" /></a>
				</div>
			</div>
		</div>
	</section>

	<!-- Footer -->
	<?php $this->load->view('layout/footer');  ?>

	<!-- Copyright -->
	<?php $this->load->view('layout/copyright'); ?>

	<!--  JavaScript -->
	<?php $this->load->view('layout/js');  ?>
	<?php if(DisclaimerPopUp == 'True'){ $this->load->view('layout/disclaimerhomepage'); }?>
	<?php if(Popbox == 'True'){ $this->load->view('layout/popbox'); }?>
	<?php if(OnLoadModal == 'True'){ $this->load->view('layout/onloadmodal'); }?>
</body>

</html>