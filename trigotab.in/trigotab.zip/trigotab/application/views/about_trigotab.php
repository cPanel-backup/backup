<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view('layout/meta');  ?>
	<?php $this->load->view('layout/styles');  ?>
	<style>
		.grid_full {
			width: 100%;
			min-height: 485px;
			max-height: 485px;
			border-radius: 26px;
		}


		.grid_full img {
			width: 100%;
		}

		.grid_divide {
			display: flex;
			justify-content: center;
			align-items: center;
			flex-direction: column;
			gap: 15px;
		}

		.text_grid_full {
			width: 100%;
			display: block;
			min-height: 485px;
			max-height: 485px;
			border-radius: 26px;
			background: #f2f2f2;
		}

		.grid_half {
			display: flex;
			background: #f2f2f2;
			width: 100%;
			min-height: 235px;
			max-height: 235px;
			flex-direction: column;
			border-radius: 26px
		}

		.text {
			width: 100%;
			line-height: 1.2em;
			overflow: hidden;
			display: -webkit-box;
			-webkit-box-orient: vertical;
			-webkit-line-clamp: 18;
		}

		.testimonial_text {
			padding: 10%;
			display: flex;
			justify-content: space-between;
			align-items: center;
			flex-direction: column;
			min-height: 256px;
		}

		.full_testimonial_text {
			padding: 10%;
			display: flex;
			justify-content: space-between;
			align-items: center;
			flex-direction: column;
			min-height: 480px;
		}

		.testimonial_detail {
			display: flex;
			justify-content: space-between;
			align-items: center;
			width: 100%;
		}
	</style>
</head>

<body id="body" data-spy="scroll" data-target=".navbar" data-offset="50">
	<!-- Page Loading -->
	<div id="loading"></div>

	<?php $this->load->view('layout/nav');  ?>

	<section class="about_trigotab_top_sec">
		<div class="left_sec_bg">
			<div class="left_sec">
				<h6>Fenugreek Seed Powder</h6>
				<h1 class="h3">Tablet 1000mg</h1>
				<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of
					classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a
					Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin
					words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in
					classical literature.</p>
				<div class="btn_cont">
					<button class="btn2 mr-md-2">Buy Now</button>
					<button class="btn2">Explore More</button>
				</div>
			</div>
		</div>
		<div class="right_sec">
			<img src="<?php echo base_url();?>assets/img/trigotab_packshot4.png" class="trigotab_packshot4" />
		</div>
	</section>

	<section class="why_choose_trigotab_sec">
		<h3>Why Choose Trigotab?</h3>
		<p>It is a long established fact that a reader will be distracted by the readable <br>content of a page when
			looking at its layout.</p>
		<div class="trigotab_description_img">
			<img src="<?php echo base_url();?>assets/img/trigotab_description.png" class="trigotab_description" />
		</div>
	</section>

	<section class="about_sec">
		<h3>Won the trust of <span>>250</span> Endo’s & <br>Diabetologists across the country</h3>
		<p>To all Diabetics including patients with stubborn glucose control</p>
	</section>

	<section class="testimonials">
		<h3>Testimonials</h3>
		<div class="tab_sec">
			<div class="tabs">
				<ul class="links">
					<li class="all">
						<a href="#">All</a>
					</li>
					<li class="videos">
						<a href="">Video Testimonials</a>
					</li>
					<li class="reviews">
						<a href="">Reviews</a>
					</li>
				</ul>
				<div class="tab-content" id="pills-tabContent">
					<div class="grid_txt">
						<div class="container">
							<div class="row">
								<div class="col-sm-4 mb-20">
									<div class="grid_full">
										<div class="about_trigotab_video_block">
											<div class="gradient">
												<img src="<?php echo base_url();?>assets/img/thumbnail1.png"
													alt="Video" />
											</div>
											<div class="about_trigotab_icon_cont">
												<a data-toggle="modal" data-target="#myModal15">
													<img src="<?php echo base_url();?>assets/img/play-button.svg"
														alt="Play Button" class="about_trigotab_play_icon" />
												</a>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-4 mb-20">
									<div class="grid_full">
										<div class="about_trigotab_video_block">
											<div class="gradient">
												<img src="<?php echo base_url();?>assets/img/thumbnail2.png"
													alt="Video" />
											</div>
											<div class="about_trigotab_icon_cont">
												<a data-toggle="modal" data-target="#myModal16">
													<img src="<?php echo base_url();?>assets/img/play-button.svg"
														alt="Play Button" class="about_trigotab_play_icon" />
												</a>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-4 mb-20">
									<div class="grid_divide">
										<div class="grid_half">
											<div class="testimonial_text">
												<p class="text">Contrary to popular belief, Lorem Ipsum is not simply
													random text. It
													has roots in a piece of classical Latin literature from 45 BC,
													making it over 2000 years old. Richard McClintock, a Latin professor
													at Hampden-Sydney College in Virginia, looked up one of the more
													obscure Latin words, consectetur.</p>
												<hr>
												<div class="testimonial_detail">
													<span class="name">Sofia (42 Years)</span>
													<span class="date">23 May, 2023</span>
												</div>
											</div>
										</div>
										<div class="grid_half">
											<div class="testimonial_text">
												<p class="text">Making it over 2000 years old. Richard McClintock, a
													Latin professor
													at Hampden-Sydney College in Virginia, looked up one of the more
													obscure Latin words, consectetur.</p>
												<hr>
												<div class="testimonial_detail">
													<span class="name">Jhon (42 Years)</span>
													<span class="date">23 May, 2023</span>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-4 mb-20">
									<div class="grid_divide">
										<div class="grid_half">
											<div class="testimonial_text">
												<p class="text">Contrary to popular belief, Lorem Ipsum is not simply
													random text. It
													has roots in a piece of classical Latin literature from 45 BC,
													making it over 2000 years old. Richard McClintock, a Latin professor
													at Hampden-Sydney College in Virginia, looked up one of the more
													obscure Latin words, consectetur.</p>
												<hr>
												<div class="testimonial_detail">
													<span class="name">Sofia (42 Years)</span>
													<span class="date">23 May, 2023</span>
												</div>
											</div>
										</div>
										<div class="grid_half">
											<div class="testimonial_text">
												<p class="text">Making it over 2000 years old. Richard McClintock, a
													Latin professor
													at Hampden-Sydney College in Virginia, looked up one of the more
													obscure Latin words, consectetur.</p>
												<hr>
												<div class="testimonial_detail">
													<span class="name">Jhon (42 Years)</span>
													<span class="date">23 May, 2023</span>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-4 mb-20">
									<div class="text_grid_full">
										<div class="full_testimonial_text">
											<p class="text">It is a long established fact that a
												reader will be distracted by the
												readable content of a page when looking at its layout. The point of
												using Lorem Ipsum is that it has a more-or-less normal distribution of
												letters, as opposed to using 'Content here, content here', making it
												look like readable English. Many desktop publishing packages and web
												page editorsInternet tend to repeat predefined chunks as necessary,
												making this the first true generator on the Internet. It uses a
												dictionary of over 200 Latin words, combined with a handful of model
												sentence structures, to generate Lorem Ipsum which looks reasonable. The
												generated Lorem Ipsum is therefore always free from repetition, injected
												humour, or non-characteristic words etc.
												paragraphswordsbyteslistsStart with 'Loremipsum dolor sit amet...'</p>
											<hr>
											<div class="testimonial_detail">
												<p class="name">Jhon (42 Years)</p>
												<p class="date">23 May, 2023</p>
											</div>
										</div>
									</div>
								</div>
								<div class="col-sm-4 mb-20">
									<div class="grid_full">
										<div class="about_trigotab_video_block">
											<div class="gradient">
												<img src="<?php echo base_url();?>assets/img/thumbnail3.png"
													alt="Video">
											</div>
											<div class="about_trigotab_icon_cont">
												<a data-toggle="modal" data-target="#myModal17">
													<img src="<?php echo base_url();?>assets/img/play-button.svg"
														alt="Play Button" class="about_trigotab_play_icon" />
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="gradient_img_cont">
		<img src="<?php echo base_url();?>assets/img/gradient_img.png" class="gradient_img" />
		<div class="gradient_img_content">
			<p>Experts Information</p>
			<h3>An add-on Towards<br> stepping down.</h3>
			<div class="btn_cont">
				<button class="btn3 mb-10">Scientific Information</button>
				<button class="btn3">Case studies</button>
			</div>
		</div>
	</section>

	<section class="faqs">
		<h3>Frequently Asked Questions</h3>
		<div class="container">
			<div class="row" id="accordion">
				<div class="col-sm-6">
					<div class="mt_3em faq">
						<div class="card">
							<div class="card-header">
								<h5 class="mb-0 hdng">
									<a class="collapsed" role="button" data-toggle="collapse" href="#collapse-1"
										aria-expanded="false" aria-controls="collapse-1">
										Where can I get some?
									</a>
								</h5>
							</div>
							<div id="collapse-1" class="collapse" data-parent="#accordion" aria-labelledby="" style="">
								<div class="card-body">
									<p>here are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteration in
										some form, by injected humour, or randomised words which don't look even
										slightly believable. If you are
										going to use a passage of Lorem Ipsum, you need to be sure there isn't anything
										embarrassing hidden in the
										middle of text.</p>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header" id="">
								<h5 class="mb-0 hdng">
									<a class="collapsed" role="button" data-toggle="collapse" href="#collapse-2"
										aria-expanded="false" aria-controls="collapse-1">
										Lorem Ipsum is simply dummy text of the printing and typesetting industry.
									</a>
								</h5>
							</div>
							<div id="collapse-2" class="collapse" data-parent="#accordion" aria-labelledby="">
								<div class="card-body">
									<p>here are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteration in some form, by injected humour, or randomised words
										which don't look even slightly believable. If you are going to use a passage of
										Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the
										middle of text.</p>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header" id="qstn-1">
								<h5 class="mb-0 hdng">
									<a class="collapsed" role="button" data-toggle="collapse" href="#collapse-3"
										aria-expanded="false" aria-controls="collapse-1">
										There are many variations of passages
									</a>
								</h5>
							</div>
							<div id="collapse-3" class="collapse" data-parent="#accordion" aria-labelledby="qstn-1">
								<div class="card-body">
									<p>here are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteration in some form, by injected humour, or randomised words
										which don't look even slightly believable. If you are going to use a passage of
										Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the
										middle of text.</p>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header" id="qstn-1">
								<h5 class="mb-0 hdng">
									<a class="collapsed" role="button" data-toggle="collapse" href="#collapse-4"
										aria-expanded="false" aria-controls="collapse-1">
										when an unknown printer took a galley of type and scrambled it.
									</a>
								</h5>
							</div>
							<div id="collapse-4" class="collapse" data-parent="#accordion" aria-labelledby="qstn-1">
								<div class="card-body">
									<p>here are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteration in some form, by injected humour, or randomised words
										which don't look even slightly believable. If you are going to use a passage of
										Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the
										middle of text.</p>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header" id="qstn-1">
								<h5 class="mb-0 hdng">
									<a class="collapsed" role="button" data-toggle="collapse" href="#collapse-5"
										aria-expanded="false" aria-controls="collapse-1">
										Contrary to popular belief, Lorem Ipsum is not simply random text.
									</a>
								</h5>
							</div>
							<div id="collapse-5" class="collapse" data-parent="#accordion" aria-labelledby="qstn-1">
								<div class="card-body">
									<p>here are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteration in some form, by injected humour, or randomised words
										which don't look even slightly believable. If you are going to use a passage of
										Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the
										middle of text.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="mt_3em faq">
						<div class="card">
							<div class="card-header" id="qstn-1">
								<h5 class="mb-0 hdng">
									<a class="collapsed" role="button" data-toggle="collapse" href="#collapse2-1"
										aria-expanded="false" aria-controls="collapse-2">
										when an unknown printer took a galley of type and scrambled it.
									</a>
								</h5>
							</div>
							<div id="collapse2-1" class="collapse" data-parent="#accordion" aria-labelledby="qstn-1"
								style="">
								<div class="card-body">
									<p>here are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteration in some form, by injected humour, or randomised words
										which don't look even slightly believable. If you are going to use a passage of
										Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the
										middle of text.</p>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header" id="qstn-1">
								<h5 class="mb-0 hdng">
									<a class="collapsed" role="button" data-toggle="collapse" href="#collapse2-2"
										aria-expanded="false" aria-controls="collapse-2">
										Contrary to popular belief, Lorem Ipsum is not simply random text.
									</a>
								</h5>
							</div>
							<div id="collapse2-2" class="collapse" data-parent="#accordion" aria-labelledby="qstn-1">
								<div class="card-body">
									<p>here are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteration in some form, by injected humour, or randomised words
										which don't look even slightly believable. If you are going to use a passage of
										Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the
										middle of text.</p>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header" id="qstn-1">
								<h5 class="mb-0 hdng">
									<a class="collapsed" role="button" data-toggle="collapse" href="#collapse2-3"
										aria-expanded="false" aria-controls="collapse-2">
										when an unknown printer took a galley of type and scrambled it.
									</a>
								</h5>
							</div>
							<div id="collapse2-3" class="collapse" data-parent="#accordion" aria-labelledby="qstn-1">
								<div class="card-body">
									<p>here are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteration in some form, by injected humour, or randomised words
										which don't look even slightly believable. If you are going to use a passage of
										Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the
										middle of text.</p>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header" id="qstn-1">
								<h5 class="mb-0 hdng">
									<a class="collapsed" role="button" data-toggle="collapse" href="#collapse2-4"
										aria-expanded="false" aria-controls="collapse-2">
										Where can I get some?
									</a>
								</h5>
							</div>
							<div id="collapse2-4" class="collapse" data-parent="#accordion" aria-labelledby="qstn-1">
								<div class="card-body">
									<p>here are many variations of passages of Lorem Ipsum available, but the majority
										have suffered alteration in some form, by injected humour, or randomised words
										which don't look even slightly believable. If you are going to use a passage of
										Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the
										middle of text.</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<div class="modal fade" id="myModal15" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content"> <button type="button" class="close" data-dismiss="modal"
					aria-label="Close"><span aria-hidden="true">×</span> </button>
				<div class="modal-body modal-video-body"> <iframe id="Video1" width="100%" height="315"
						src="https://www.youtube.com/embed/IUN664s7N-c" title="YouTube video player" frameborder="0"
						allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
						allowfullscreen></iframe> </div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="myModal16" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content"> <button type="button" class="close" data-dismiss="modal"
					aria-label="Close"><span aria-hidden="true">×</span> </button>
				<div class="modal-body modal-video-body"> <iframe id="Video2" width="100%" height="315"
						src="https://www.youtube.com/embed/IUN664s7N-c" title="YouTube video player" frameborder="0"
						allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
						allowfullscreen></iframe> </div>
			</div>
		</div>
	</div>
	<div class="modal fade" id="myModal17" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content"> <button type="button" class="close" data-dismiss="modal"
					aria-label="Close"><span aria-hidden="true">×</span> </button>
				<div class="modal-body modal-video-body"> <iframe id="Video3" width="100%" height="315"
						src="https://www.youtube.com/embed/IUN664s7N-c" title="YouTube video player" frameborder="0"
						allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
						allowfullscreen></iframe> </div>
			</div>
		</div>
	</div>

	<!-- Footer -->
	<?php $this->load->view('layout/footer');  ?>

	<!-- Copyright -->
	<?php $this->load->view('layout/copyright'); ?>

	<!--  JavaScript -->
	<?php $this->load->view('layout/js');  ?>
	<?php if(DisclaimerPopUp == 'True'){ $this->load->view('layout/disclaimerhomepage'); }?>
	<?php if(Popbox == 'True'){ $this->load->view('layout/popbox'); }?>
	<?php if(OnLoadModal == 'True'){ $this->load->view('layout/onloadmodal'); }?>
	<script>
		$(document).ready(function () {
			$("#close").click(function () {
				$("#video_model").hide(300);
			});
			var url =
				$("#Video1").attr('src');
			$("#myModal15").on('hide.bs.modal', function () {
				$("#Video").attr('src', '');
			});
			$("#myModal15").on('show.bs.modal', function () {
				$("#Video").attr('src', url);
			});
		});
		$(document).ready(function () {
			$("#close").click(function () {
				$("#video_model1").hide(300);
			});
			var url =
				$("#Video2").attr('src');
			$("#myModal16").on('hide.bs.modal', function () {
				$("#Video1").attr('src', '');
			});
			$("#myModal16").on('show.bs.modal', function () {
				$("#Video1").attr('src', url);
			});
		});
		$(document).ready(function () {
			$("#close").click(function () {
				$("#video_model2").hide(300);
			});
			var url =
				$("#Video3").attr('src');
			$("#myModal17").on('hide.bs.modal', function () {
				$("#Video2").attr('src', '');
			});
			$("#myModal17").on('show.bs.modal', function () {
				$("#Video2").attr('src', url);
			});
		});
	</script>
</body>

</html>