<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('layout/meta');  ?>
    <?php $this->load->view('layout/styles');  ?>
</head>

<body>
    <?php $this->load->view('layout/admin_nav');  ?>
    <section class="main">
        <nav aria-label="breadcrumb" class="_breadcrumb">
            <div class="container">
                <h1>Create page</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page">Pages</li>
                    <li class="breadcrumb-item active" aria-current="page">Create page</li>
                </ol>
            </div>
        </nav>
        <div class="container">
        <form id="create_page" name="" method="post">
            <div class="card">
                <div class="card-header">
                    Create new page
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="form-group">
                                <label for="groupname">Page name</label>
                                <input type="text" class="form-control" id="page_name" name="page_name">
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <label>Page group</label>
                            <div class="form-group">
                                <select name="country" id="country" class="form-control">
                                    <option></option>
                                    <option value="India">India</option>
                                    <option value="austrailia">Australia</option>
                                    <option value="Malaysia">Malaysia</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12 mt-3">
                            <div class="form-group">
                                <label for="groupname">URL</label>
                                <input type="text" class="form-control" id="" name="url" >
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <input type="submit" class="btn btn-primary my-1 m-3" id="" name="" value="Submit">
                    <input type="reset" class="btn btn-danger m-3" id="" name="" value="Reset">
                    <a href="#" class="btn btn-secondary m-3">Cancel</a>                 
                </div>
            </div>
            </form>
        </div>
    </section>

    <!--  Copyright -->
    <footer>
    <?php $this->load->view('layout/admin_copyright');  ?>
    </footer>
    <!-- End Copyright -->
    <!--  JavaScript -->
    <?php $this->load->view('layout/js');  ?>
    <!--  End JavaScript -->
    
</body>

</html>