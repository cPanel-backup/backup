<!DOCTYPE html>
<html lang="en">
<head>
    <?php $this->load->view('layout/meta');  ?>
	<?php $this->load->view('layout/styles');  ?>
</head>
<body>
    <?php $this->load->view('layout/admin_nav');  ?>
    <section class="main">
        <nav aria-label="breadcrumb" class="_breadcrumb">
            <div class="container">
            <h1>Home</h1>
            <ol class="breadcrumb">
            <div class="container mt-3">
                <li class="breadcrumb-item active" aria-current="page"></li>
            </ol> 
            </div>
        </nav>
    </div>
    </section>
    <!--  Copyright -->
    <?php $this->load->view('layout/admin_copyright');  ?>
    <!-- End Copyright -->
	<!--  JavaScript -->
    <?php $this->load->view('layout/js');  ?>
    <!--  End JavaScript -->
</body>
</html>