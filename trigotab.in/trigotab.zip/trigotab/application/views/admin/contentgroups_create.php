<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('layout/meta');  ?>
    <?php $this->load->view('layout/styles');  ?>
</head>

<body>
    <?php $this->load->view('layout/admin_nav');  ?>
    <section class="main">
        <nav aria-label="breadcrumb" class="_breadcrumb">
            <div class="container">
                <h1>Create content group</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page">Content Group</li>
                    <li class="breadcrumb-item active" aria-current="page">Create content group</li>
                </ol>
            </div>
        </nav>
    <div class="container mt-3">
    <form id="content_group" name="" method="post">
        <input type="hidden" name="logid" value="<?php echo $this->session->userdata('id'); ?>">
            <div class="card">
                <div class="card-header">
                Create content group
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label for="groupname">Content groups</label>
                        <input type="text" class="form-control" id="group_name" name="group_name">
                    </div>
                </div>
                <div class="card-footer">
                    <input type="submit" class="btn btn-primary my-1 m-3" id="submit" name="create" value="Submit">
                    <input type="reset" class="btn btn-danger my-1 m-3" id="reset" name="reset" value="Reset">
                    <a href="#" class="btn btn-secondary m-3">Cancel</a>   
                </div>
            </div>
        </form>
    </div>
    </section>
    <!--  Copyright -->
    <?php $this->load->view('layout/admin_copyright');  ?>
    <!-- End Copyright -->
    <!--  JavaScript -->
    <?php $this->load->view('layout/js');  ?>
    <!--  End JavaScript -->
</body>

</html>