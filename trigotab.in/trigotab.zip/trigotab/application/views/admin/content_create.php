<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('layout/meta');  ?>
    <?php $this->load->view('layout/styles');  ?>
</head>

<body>
    <?php $this->load->view('layout/admin_nav');  ?>
    <section class="main">
        <nav aria-label="breadcrumb" class="_breadcrumb">
            <div class="container">
                <h1>Create content</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page">Content</li>
                    <li class="breadcrumb-item active" aria-current="page">Create content</li>
                </ol>
            </div>
        </nav>
        <div class="container">
        
        <form id="content_create" name="" method="post">
            <input type="hidden" name="logid" value="<?php echo $this->session->userdata('id'); ?>">
            <div class="card">
                <div class="card-header">
                    Create new content
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-sm-12">
                            <label>Content Group</label>
                            <div class="form-group">
                                <select name="group_code" id="country" class="form-control" required>
                                    <option value="">Select Content Group</option>
                                    <?php if(empty($contentgroups)){ echo '<option value="">No Data</option>'; }else { ?>
            							<?php foreach($contentgroups as $contentgroups_list) {?>
        							        <option value="<?php echo $contentgroups_list['group_code']; ?>"><?php echo $contentgroups_list[ 'group_name']; ?></option>
        							    <?php } ?>
        							<?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12 mt-3">
                            <div class="form-group">
                                <label>Content </label>
                                <textarea class="form-control" name="content" id="editor-" required></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <input type="submit" class="btn btn-primary my-1 m-3" id="submit" name="create" value="Submit">
                    <input type="reset" class="btn btn-danger m-3" id="reset" name="reset" value="Reset">
                    <a href="#" class="btn btn-secondary m-3">Cancel</a>                 
                </div>
            </div>
            </form>
        </div>
    </section>

    <script src="https://cdn.tiny.cloud/1/qagffr3pkuv17a8on1afax661irst1hbr4e6tbv888sz91jc/tinymce/6/tinymce.min.js"></script>
    <!--  Copyright -->
    <footer>
    <?php $this->load->view('layout/admin_copyright');  ?>
    </footer>
    <!-- End Copyright -->
    <!--  JavaScript -->
    <?php $this->load->view('layout/js');  ?>
    <!--  End JavaScript -->
    <script>
        $( document ).ready(function() {
            tinymce.init({
            selector:'#editor',
            menubar: false,
            statusbar: false,
            plugins: 'autoresize anchor autolink charmap code codesample directionality fullpage help hr image imagetools insertdatetime link lists media nonbreaking pagebreak preview print searchreplace table template textpattern toc visualblocks visualchars',
            toolbar: 'h1 h2 bold italic strikethrough blockquote bullist numlist backcolor | link image media | removeformat help fullscreen ',
            skin: 'bootstrap',
            toolbar_drawer: 'floating',
            min_height: 200,           
            autoresize_bottom_margin: 16,
            setup: (editor) => {
                editor.on('init', () => {
                    editor.getContainer().style.transition="border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out"
                });
                editor.on('focus', () => {
                    editor.getContainer().style.boxShadow="0 0 0 .2rem rgba(0, 123, 255, .25)",
                    editor.getContainer().style.borderColor="#80bdff"
                });
                editor.on('blur', () => {
                    editor.getContainer().style.boxShadow="",
                    editor.getContainer().style.borderColor=""
                });
            }
        }); 
    }); 
    </script>
</body>

</html>