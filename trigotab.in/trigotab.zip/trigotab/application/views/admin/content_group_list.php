<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('layout/meta');  ?>
    <?php $this->load->view('layout/styles');  ?>
</head>

<body>
    <?php $this->load->view('layout/admin_nav');  ?>
    <section class="main">
        <nav aria-label="breadcrumb" class="_breadcrumb">
            <div class="container">
                <h1>List of content groups</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item active" aria-current="page">Content Groups</li>
                    <li class="breadcrumb-item active" aria-current="page">List of content groups</li>
                </ol>
            </div>
        </nav>
    <?php //print_r($contentgroups); ?>
    <div class="container">
        <table id="example" class="table table-striped table-bordered">
            <tr>
                <th>S No</th>
                <th>Code</th>
                <th>Group</th>
                <th>Status</th>
            </tr>
            <?php if(empty($contentgroups)){ }else { ?>
            	<?php foreach($contentgroups as $contentgroup_list) {?>
                	<tr>
                        <th><?php echo $contentgroup_list['content_group_id']; ?></th>
                        <th><?php echo $contentgroup_list['group_code']; ?></th>
                        <th><?php echo $contentgroup_list['group_name']; ?></th>
                        <th><?php echo $contentgroup_list['group_status']; ?></th>
                    </tr>
			    <?php } ?>
			<?php } ?>
        </table>
    </div>
    </section>
    <!--  Copyright -->
    <?php $this->load->view('layout/admin_copyright');  ?>
    <!-- End Copyright -->
    <!--  JavaScript -->
    <?php $this->load->view('layout/js');  ?>
    <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.bootstrap4.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
    <script>
       $(document).ready(function() {
            var table = $('#example').DataTable( {
                lengthChange: false,
                buttons: [
                    {
                        extend: 'excelHtml5',
                        title: 'List of content groups'
                    }
                ]
            });
            table.buttons().container()
                .appendTo( '#example_wrapper .col-md-6:eq(0)' );
        });
    </script>
    <!--  End JavaScript -->
</body>
</html>