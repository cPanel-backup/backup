<!DOCTYPE html>
<html lang="en">

<head>
    <?php $this->load->view('layout/meta');  ?>
    <?php $this->load->view('layout/styles');  ?>
</head>

<body id="body" data-spy="scroll" data-target=".navbar" data-offset="50">
    <!-- Page Loading -->
    <div id="loading"></div>

    <?php $this->load->view('layout/nav');  ?>
    <section class="contactUs">
        <div class="container">
            <div class="row">
                <div class="col-sm-5 left_sec">
                    <div class="left_sec_bg_img">
                        <img src="<?php echo base_url();?>assets/img/Mask_group.png" class="Mask_group"/>
                    </div>
                    <div class="left_sec_cont">
                        <h1 class="h4">Contact Us</h1>
                        <p>Get in Touch with us or fill the form to know more about product.</p>
                        <div class="contact_icon one">
                            <img src="<?php echo base_url();?>assets/img/dail.svg" />
                            <p>+91-98765 43210</p>
                        </div>
                        <div class="contact_icon two">
                            <img src="<?php echo base_url();?>assets/img/mail.svg" />
                            <p>lead@heterohealthcare.com</p>
                        </div>
                        <div class="contact_icon three">
                            <img src="<?php echo base_url();?>assets/img/location.svg" />
                            <p>sy no 80-84, 4th floor, Melange Towers, Patrika Nagar, Madhapur, Hyderabad, Telangana
                                500081</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-7 right_sec">
                    <h4>Write to Us</h4>
                    <p>Get in Touch with us or fill the form to know more about product.</p>
                    <form id="consultUs" method="post" name="consult_us">
                        <div class="row">
                            <div class="col-sm-6 mb-3">
                                <label for="name" form-control>Full name</label>
                                <input type="text" id="name" autocomplete="off" name="name"
                                    class="form-control custom_input" placeholder="Full Name" />
                            </div>
                            <div class="col-sm-6 mb-3">
                                <label for="email">Email address</label>
                                <input id="email" autocomplete="off" name="email" type="email"
                                    class="form-control custom_input" placeholder="Email" />
                            </div>
                            <div class="col-sm-6 mb-3">
                                <label for="number">Contact number</label>
                                <input id="contact" autocomplete="off" name="contact" type="text"
                                    class="form-control custom_input" placeholder="Phone Number" />
                            </div>
                            <div class="col-sm-6 mb-3 d-flex flex-column">
                                <label for="email">Enquiry type</label>
                                <select class="form-control custom_input">
                                    <option selected>Select</option>
                                    <option value="1">One</option>
                                    <option value="2">Two</option>
                                    <option value="3">Three</option>
                                </select>
                            </div>
                            <div class="col-sm-12 mb-3 d-flex flex-column">
                                <label for="message">Message</label>
                                <textarea col="50" rows="2" id="message" name="message" class="custom_input"></textarea>
                            </div>
                            <div class="form-group col-md-12">
                                <input type="submit" class="btn" />
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- Footer -->
    <?php $this->load->view('layout/footer');  ?>

    <!-- Copyright -->
    <?php $this->load->view('layout/copyright'); ?>

    <!--  JavaScript -->
    <?php $this->load->view('layout/js');  ?>
    <?php if(DisclaimerPopUp == 'True'){ $this->load->view('layout/disclaimerhomepage'); }?>
    <?php if(Popbox == 'True'){ $this->load->view('layout/popbox'); }?>
    <?php if(OnLoadModal == 'True'){ $this->load->view('layout/onloadmodal'); }?>
    <script>
        $(document).ready(function () {
            $('input[name="contact"]').keyup(function (e) {
                if (/\D/g.test(this.value)) {
                    // Filter non-digits from input value.
                    this.value = this.value.replace(/\D/g, '');
                }
            });
            // Setup form validation on the #register-form element
            $("#consultUs").validate({

                // Specify the validation rules
                rules: {
                    name: {
                        required: true,
                        minlength: 3,
                        maxlength: 50
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    contact: {
                        required: true,
                        number: true,
                        minlength: 10,
                        maxlength: 15
                    },
                    message: {
                        required: true,
                        message: true
                    }
                },

                // Specify the validation error messages
                messages: {
                    name: {
                        required: "Please enter your name",
                        maxlength: "Please Enter Below 50 Characters"
                    },
                    email: {
                        required: "Please enter your email address",
                        email: "Please enter a valid email address"
                    },
                    contact: {
                        required: "Please enter your contact number",
                        number: "Please Enter Digits Only",
                        maxlength: "Please enter below 10 digits"
                    },
                    message: {
                        required: "Please enter message"
                    }
                },

                submitHandler: function (form) {

                    if ($("#submit").val("Processing...")) {
                        $("#submit").prop('disabled', 'disabled');
                    }
                    var myForm = document.getElementById('consultUs');
                    $.ajax({
                        type: 'post',
                        url: "",
                        dataType: 'text',
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: new FormData(myForm),
                        success: function (data) {
                            window.location = data;
                        }
                    });
                    return false;
                }
            });
        });
    </script>
</body>

</html>




